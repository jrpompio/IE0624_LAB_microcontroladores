 Para compilar este codigo en el IDE de arduino se necesitará agregar la siguiente libreria:

    https://github.com/arkhipenko/TaskScheduler

Dicha libreria permite realizar multiples tareas en ejecución periodica.
