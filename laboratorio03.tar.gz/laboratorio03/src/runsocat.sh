#!/bin/sh
socat PTY,link=/tmp/ttyS0,raw,echo=0 PTY,link=/tmp/ttyS1,raw,echo=0
chmod 666 /tmp/ttyS*
